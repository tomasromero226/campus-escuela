<?php
/* =====================================================================
   ARCHIVO: includes/usuarios.php
   PARA QUÉ SIRVE: guarda y lee los usuarios registrados (alumnos y
   profesores) en un archivo, y envía los correos con contraseñas/códigos.

   ¿POR QUÉ UN ARCHIVO?
   Un array de PHP se "olvida" en cada carga de página, así que un
   usuario recién registrado desaparecería. Por eso guardamos todo en
   data/usuarios.json (un archivo de texto con formato JSON).
   Es una solución simple para aprender; en un sistema real se usa MySQL.

   NOTA: los DIRECTIVOS no se guardan aquí: se definen solo en
   includes/datos.php, porque NO pueden registrarse por su cuenta.
   ===================================================================== */
require_once __DIR__ . '/config.php';


/* ---------------------------------------------------------------------
   FUNCIÓN: asegurarCarpetaData()
   Crea la carpeta /data si todavía no existe.
   --------------------------------------------------------------------- */
function asegurarCarpetaData() {
    $carpeta = dirname(ARCHIVO_USUARIOS);
    if (!is_dir($carpeta)) {
        mkdir($carpeta, 0755, true);
    }
}


/* ---------------------------------------------------------------------
   FUNCIÓN: guardarUsuarios($bd)
   Escribe la lista completa de usuarios en data/usuarios.json.
   Devuelve true si pudo guardar, false si falló (por ejemplo, por permisos).
   --------------------------------------------------------------------- */
function guardarUsuarios($bd) {
    asegurarCarpetaData();
    // json_encode convierte el array de PHP en texto JSON
    $json = json_encode($bd, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    // LOCK_EX evita que dos registros simultáneos se pisen entre sí
    return file_put_contents(ARCHIVO_USUARIOS, $json, LOCK_EX) !== false;
}


/* ---------------------------------------------------------------------
   FUNCIÓN: cargarUsuarios()
   Devuelve un array con dos listas: ['alumnos' => [...], 'profesores' => [...]]
   Si el archivo todavía no existe (primera vez), lo crea usando los
   usuarios de ejemplo de includes/datos.php.
   --------------------------------------------------------------------- */
function cargarUsuarios() {
    if (!file_exists(ARCHIVO_USUARIOS)) {
        // Primera vez: cargamos los usuarios de ejemplo
        require __DIR__ . '/datos.php';   // Define $ALUMNOS y $PROFESORES
        $bd = ['alumnos' => $ALUMNOS, 'profesores' => $PROFESORES];
        guardarUsuarios($bd);
        return $bd;
    }

    // Leemos el archivo y lo convertimos otra vez en array
    $bd = json_decode(file_get_contents(ARCHIVO_USUARIOS), true);

    // Si el archivo estuviera dañado o vacío, devolvemos listas vacías
    if (!is_array($bd)) {
        $bd = ['alumnos' => [], 'profesores' => []];
    }
    // Garantizamos que ambas listas existan
    $bd['alumnos']    = $bd['alumnos']    ?? [];
    $bd['profesores'] = $bd['profesores'] ?? [];
    return $bd;
}


/* ---------------------------------------------------------------------
   FUNCIÓN: enviarCorreo($para, $asunto, $mensaje)
   Envía un correo (o lo simula, según MODO_PRUEBA en config.php).
   Devuelve true si todo salió bien.
   --------------------------------------------------------------------- */
function enviarCorreo($para, $asunto, $mensaje) {

    // ---- MODO PRUEBA: no se envía nada, se anota en un archivo de texto ----
    if (MODO_PRUEBA) {
        asegurarCarpetaData();
        $registro = '[' . date('Y-m-d H:i:s') . '] PARA: ' . $para
                  . ' | ASUNTO: ' . $asunto . "\n" . $mensaje . "\n----------\n";
        return file_put_contents(ARCHIVO_CORREOS, $registro, FILE_APPEND | LOCK_EX) !== false;
    }

    // ---- MODO REAL: envío con mail() ----
    // AQUÍ SE PUEDE CAMBIAR mail() POR PHPMailer (con SMTP) para mayor confiabilidad
    $cabeceras  = 'From: ' . CORREO_REMITENTE . "\r\n";
    $cabeceras .= "Content-Type: text/plain; charset=UTF-8\r\n";
    // Codificamos el asunto para que se vean bien las tildes
    $asuntoCodificado = '=?UTF-8?B?' . base64_encode($asunto) . '?=';
    return mail($para, $asuntoCodificado, $mensaje, $cabeceras);
}
