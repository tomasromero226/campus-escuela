<?php
/* =====================================================================
   ARCHIVO: includes/config.php
   PARA QUÉ SIRVE: reúne los AJUSTES del sistema en un solo lugar.
   Si necesita cambiar algo de cómo funciona el registro, es aquí.
   ===================================================================== */

/* ---------------------------------------------------------------------
   MODO_PRUEBA
   true  = NO se envían correos reales. En su lugar:
             - el mensaje se guarda en data/correos_simulados.txt
             - y la contraseña/código se muestra en pantalla.
           (Úselo en su computadora, porque XAMPP no puede enviar correos.)
   false = se envían correos reales con la función mail() de PHP.
           (Úselo SOLO cuando el sitio esté en un hosting con correo.)
   AQUÍ SE CAMBIA EL MODO.
   --------------------------------------------------------------------- */
define('MODO_PRUEBA', true);

/* ---------------------------------------------------------------------
   CORREO REMITENTE: la dirección que aparece como "De:" en los correos.
   AQUÍ SE CAMBIA por el correo real de la escuela.
   --------------------------------------------------------------------- */
define('CORREO_REMITENTE', 'campus@escuela.edu.ar');

/* ---------------------------------------------------------------------
   CLAVE DE REGISTRO DE PROFESORES
   Para que cualquier persona NO pueda registrarse como profesor (y así
   reservar proyectores), el formulario pide esta clave. La escuela se la
   entrega solo a sus docentes.
   AQUÍ SE CAMBIA LA CLAVE. Si la deja vacía ('') no se pedirá (NO recomendado).
   --------------------------------------------------------------------- */
define('CLAVE_REGISTRO_PROFESOR', 'ESCUELA2026');

/* ---------------------------------------------------------------------
   RUTAS DE ARCHIVOS (__DIR__ es la carpeta "includes"; subimos un nivel)
   --------------------------------------------------------------------- */
define('ARCHIVO_USUARIOS', __DIR__ . '/../data/usuarios.json');         // "Base de datos"
define('ARCHIVO_CORREOS',  __DIR__ . '/../data/correos_simulados.txt'); // Correos del modo prueba
